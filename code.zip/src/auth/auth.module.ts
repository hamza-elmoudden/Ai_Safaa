import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { PrismaModule } from 'src/prisma/prisma.module';
import { UsersModule } from 'src/users/users.module';
import { PassportModule } from '@nestjs/passport';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { GoogleStrategy } from './Google.strategy';
import { JwtStrategy } from './Jwt.strategy';
import { JwtRefreshStrategy } from './Jwt.refresh.strategy';
import { PaymentsModule } from 'src/payments/payments.module';
import { SubscriptionsModule } from 'src/subscriptions/subscriptions.module';


@Module({
  providers: [

    AuthService,
    GoogleStrategy,       // GET /auth/google/callback
    JwtStrategy,          // Bearer access token
    JwtRefreshStrategy,
  ],
  controllers: [AuthController],
  imports: [
    UsersModule,
    PrismaModule,
    PassportModule,
    ConfigModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret: config.getOrThrow('JWT_SECRET'),
        signOptions: { expiresIn: config.getOrThrow('JWT_EXPIRATION') },
      }),
    }),
    PaymentsModule,
    SubscriptionsModule

  ],
})
export class AuthModule { }
